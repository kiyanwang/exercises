//
// This is only a SKELETON file for the 'Simple Linked List' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Element {
  constructor() {
   
  }

  get value() {
    throw new Error('Remove this statement and implement this function');
  }

  get next() {
    throw new Error('Remove this statement and implement this function');
  }
}

export class List {
  constructor() {
    throw new Error('Remove this statement and implement this function');
  }

  add(nextValue) {
    throw new Error('Remove this statement and implement this function');
  }

  get length() {
    throw new Error('Remove this statement and implement this function');
  }

  get head() {
    throw new Error('Remove this statement and implement this function');
  }

  toArray() {
    throw new Error('Remove this statement and implement this function');
  }

  reverse() {
    throw new Error('Remove this statement and implement this function');
  }
}
